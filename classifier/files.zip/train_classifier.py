import csv
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib

FEATURES = ["ela", "edge", "noise_texture", "sharpness"]


def load_dataset(path="dataset.csv"):
    X, y = [], []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            X.append([float(row[k]) for k in FEATURES])
            y.append(int(row["label"]))
    return np.array(X), np.array(y)


def train(path="dataset.csv", model_out="tamper_model.joblib"):
    X, y = load_dataset(path)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    clf = LogisticRegression(class_weight="balanced", max_iter=1000)
    clf.fit(X_train, y_train)

    preds = clf.predict(X_test)
    print("Test accuracy:", accuracy_score(y_test, preds))
    print(classification_report(y_test, preds, target_names=["genuine", "tampered"]))

    print("\nLearned feature weights (higher = more this signal pushes toward 'tampered'):")
    for name, coef in zip(FEATURES, clf.coef_[0]):
        print(f"  {name:15s}: {coef:+.3f}")

    joblib.dump(clf, model_out)
    print(f"\nModel saved to {model_out}")
    return clf


if __name__ == "__main__":
    train()
